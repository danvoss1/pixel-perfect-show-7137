import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Box, ExternalLink } from "lucide-react";
import { GameShell } from "@/components/game/GameShell";
import { LockedContent } from "@/components/game/primitives";
import { usePlayer } from "@/game/store";

export const Route = createFileRoute("/3d")({
  head: () => ({
    meta: [
      { title: "3D — Der verborgene Pfad" },
      {
        name: "description",
        content: "Die freigeschaltete 3D-Rekonstruktion der Expedition.",
      },
    ],
  }),
  component: ThreeDArchive,
});

function ThreeDArchive() {
  const unlocked = usePlayer((s) => s.unlockedFeatures.includes("3d"));

  if (!unlocked) {
    return (
      <GameShell>
        <LockedContent note="Für diesen Bereich fehlt noch die dritte Dimension." />
        <Link
          to="/adventure"
          className="mt-6 block text-center label-mono text-primary"
        >
          Zurück zur Expedition
        </Link>
      </GameShell>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="flex min-h-14 shrink-0 items-center justify-between gap-3 border-b border-border bg-surface/95 px-3 py-2 backdrop-blur sm:px-4">
        <div className="flex min-w-0 items-center gap-3">
          <Link
            to="/adventure"
            className="inline-flex min-h-10 shrink-0 items-center gap-2 rounded-md border border-border bg-background/60 px-3 text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <ArrowLeft className="size-4" />
            <span className="hidden sm:inline">Expedition</span>
          </Link>

          <div className="grid size-9 shrink-0 place-items-center rounded-md border border-primary/40 bg-primary/5">
            <Box className="size-5 text-primary" />
          </div>

          <div className="min-w-0">
            <p className="label-mono truncate text-primary">3D · Rekonstruktion</p>
            <h1 className="truncate font-display text-sm font-bold uppercase sm:text-base">
              Szene 01 · Heumarkt
            </h1>
          </div>
        </div>

        <a
          href="/heumarkt-3d/index.html"
          target="_blank"
          rel="noreferrer"
          className="inline-flex min-h-10 shrink-0 items-center gap-2 rounded-md border border-border bg-background/60 px-3 text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          title="3D-Modell in einem eigenen Tab öffnen"
        >
          <ExternalLink className="size-4" />
          <span className="hidden sm:inline">Vollbild</span>
        </a>
      </header>

      <div className="min-h-0 flex-1 bg-[#101827]">
        <iframe
          src="/heumarkt-3d/index.html"
          title="Heumarkt 3D-Rekonstruktion"
          className="block h-[calc(100dvh-3.5rem)] w-full border-0"
          allow="fullscreen"
        />
      </div>
    </div>
  );
}
